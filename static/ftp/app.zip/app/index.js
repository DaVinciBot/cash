const http = require('http');
const { Pool } = require('pg');
const url = require('url');
const fs = require('fs');

// Read password from Docker secret file if it exists
let dbPassword = process.env.DB_PASSWORD || 'postgres';
const passwordFile = process.env.DB_PASSWORD_FILE;
if (passwordFile) {
    try {
        dbPassword = fs.readFileSync(passwordFile, 'utf8').trim();
    } catch (error) {
        console.error('Could not read password file:', error.message);
    }
}

// PostgreSQL connection pool
const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'postgres',
    user: process.env.DB_USER || 'postgres',
    password: dbPassword,
});

const server = http.createServer(async (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;

    // Root route
    if (pathname === '/') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('Hello World!\n');
    }
    // Database route
    else if (pathname === '/data' && req.method === 'GET') {
        try {
            const result = await pool.query('SELECT NOW() as current_time, version() as version');
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                success: true,
                data: result.rows
            }, null, 2));
        } catch (error) {
            console.error('Database error:', error);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                success: false,
                error: error.message
            }));
        }
    }
    // 404 route
    else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found\n');
    }
});

const PORT = 80;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

